To compile and run the program, save the code to a file named bertrand_paradox.cpp and execute the following commands in a terminal:

## bash
g++ -o bertrands_paradox bertrand_paradox.cpp
./bertrand_paradox

The output should be the estimated probabilities for each strategy, separated by newlines.

Note: This program uses the rand() function from the C standard library to generate random numbers. The rand() function returns a pseudo-random number between 0 and RAND_MAX, which is a macro defined in the cstdlib header file. The RAND_MAX value is implementation-defined, but it is guaranteed to be at least 32767. In this program, we assume that RAND_MAX is 32767, which means that the range of rand() is [0, 32767]. Therefore, the range of the generated random numbers is scaled down to [0, 100] by dividing the result