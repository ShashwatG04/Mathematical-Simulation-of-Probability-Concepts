

#include<iostream>
#include<cmath>
using namespace std;

double strategy_1()
{   
    int count = 0;
    int simulations = 0;
    while(simulations <= pow(10,6))
    {
            double angle; 
            angle = (double)rand() / RAND_MAX * 90; // a random angle between 0 and 90
            if (angle >= 0 && angle <= 30) // if the angle is between 0 and 30 check
            {
                count++; // Increment the count 
            }
            simulations++;
        
    }
    return (double)count / simulations; //   probability
}
double strategy_2()
{
    int count =0;
    int simulations = 0;
    //let  fix the radius of the circle to be 100
    
    while(simulations <= pow(10,6))
    {
       double length; 
       length = (double)rand() / RAND_MAX * 100; //  a random length between 0 and 100
       if(length >= 0 && length <= 50) // if the length is between 0 and 50  check
       {
           count++; // count if the condition is met
       }
         simulations++;
    }

   return (double)count / simulations; //  the probability

}
double strategy_3()
{
    int count =0;
    int simulations = 0;
    //let  fix the radius of the circle to be 100
    
    while(simulations <= pow(10,6))
    {
       double radius; 
       radius = (double)rand() / RAND_MAX * 100; //  a random radius between 0 and 100
       if(radius >= 0 && radius <= 50) //  if the radius is between 0 and 50 check
       {
           count++; //  count if the condition is met
       }
         simulations++;
    }

   double result = (double)count / simulations; 
   return result*result; // the probability
}
int main()
{
    cout<<strategy_1()<<endl;
    cout<<strategy_2()<<endl;
    cout<<strategy_3()<<endl;
    return 0;
} 