# Compile the C++ source code using a C++ compiler (e.g., g++)
# Run the compiled program, providing p as a command-line argument
# The program will output the minimum number of students (k) required to ensure the probability that at least two students have the same birthday is greater than p
# Here is an example of how to run the code:

sh

$ g++ birthday_paradox1.cpp -o birthday_paradox1
$ ./birthday_paradox1 0.1
230

# Algorithm
# The solution uses a function called calpro to calculate the probability that at least two students have the same birthday, given a number of students (k). The function takes a single integer argument k, and returns a float value representing the probability.

# The code then defines a function findK to find the smallest number of students (k) required for a given probability (p):

# The function calculates the log of the given probability (p) and stores it in the variable lp
# The function then iterates through all possible numbers of students (k) from 1 to 366, and calculates the probability for each k using the calpro function
# If the calculated probability is less than the given probability (p), the function returns the current number of students (k) as the result
# The program then enters the main() function and reads the required probability (p) as a user input. It then calls the findK function and outputs the returned number of students (k).