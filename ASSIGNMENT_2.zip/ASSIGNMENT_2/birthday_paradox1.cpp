#include <iostream>
#include <bits/stdc++.h>
using namespace std;

float calpro(int a)
{
    float temp = ((365 + 0.5) * log(365)) - ((365 - a + 0.5) *log(365 - a) + a) - a * log(365);
    return temp;
}

int findK(float p)
{
    float lp = log(p);
    for (int i = 1; i < 367; i++)
    {
        float temp = calpro(i);
        if(temp < lp){
            return i;
        }
    }
    return -1;
}

int main()
{
    float p;
    cin >> p;
    cout << findK(1-p);
    return 0;
}