RUN the code in VSCode
The code will prompt you to enter the lower and upper bounds of the interval. You can either enter the values or press Enter to use the default values (0 and 1).

The code will then generate one million random samples within the specified interval and plot a histogram of the generated samples.
#output
The code will generate a histogram of the generated samples and display it in a new window. The histogram will show the distribution of the generated samples and their mean and standard deviation.

Additionally, the code will save the histogram as a PNG file named dist_plot.png in the same directory as the Python script.