import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta

# Define the observed data
data = np.array(['H', 'H', 'H', 'T', 'T', 'T', 'H', 'H', 'H', 'T'])
heads = np.sum(data == 'H')
tails = len(data) - heads

# Define prior parameters for each case
priors = [(2, 5), (5, 2), (1, 1), (2, 2)]

# Initialize plot
plt.figure(figsize=(12, 8))

# Plot posterior distributions for each case
for i, prior_params in enumerate(priors, start=1):
    alpha_prior, beta_prior = prior_params
    alpha_posterior = alpha_prior + heads
    beta_posterior = beta_prior + tails
    posterior = beta(alpha_posterior, beta_posterior)

    # Compute MLE and MAP estimates
    mle = heads / len(data)
    map_estimate = (alpha_posterior - 1) / (alpha_posterior + beta_posterior - 2)

    # Plot posterior distribution
    plt.subplot(2, 2, i)
    x = np.linspace(0, 1, 1000)
    plt.plot(x, posterior.pdf(x), label='Posterior')
    plt.axvline(x=mle, color='r', linestyle='--', label='MLE')
    plt.axvline(x=map_estimate, color='g', linestyle='--', label='MAP')
    plt.title(f'Prior Beta({alpha_prior}, {beta_prior})')
    plt.xlabel('Probability of Heads')
    plt.ylabel('Density')
    plt.legend()

plt.tight_layout()
plt.show()