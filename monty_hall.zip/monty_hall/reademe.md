

## Instructions to Run the Code



1. Run the Python script in the vscode terminal by navigating to the directory containing the code files.

## Explanation of User Input

The code prompts the user to select an action:
- Enter `1` to exit.
- Enter `2` to plot a graph.
- Enter `3` to find the probability.

When prompted to find the probability, you will be asked to input the values of `n` (total doors) and `k` (number of doors to choose).

## Output Description

The code calculates and prints the probabilities of winning for different strategies. Optionally, it can also plot a graph.


